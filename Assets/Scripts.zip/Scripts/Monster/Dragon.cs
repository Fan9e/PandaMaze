using UnityEngine;

public class Dragon : Monster
{
    /// <summary>
    /// Initialiserer dragen ved at s�tte dens maksimale liv og angrebskraft
    /// og kalder Monster-basislogikken via base.Start().
    /// </summary>
    private void Start()
    {
        MaxHealth = 30;
        AttackPower = 5;
        base.Start();
    }

}
