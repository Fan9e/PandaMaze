using UnityEngine;

/// <summary>
/// Interface for at modtage opdateringer fra stemmegenkendelse og mikrofon.
/// </summary>
public interface IVoiceObserver
{
    /// <summary>
    /// Kaldes n�r et delvist (mellemliggende) genkendelsesresultat er tilg�ngeligt.
    /// </summary>
    /// <param name="partial">Det delvise tekstresultat fra genkendelsen.</param>
    void OnPartialResult(string partial);

    /// <summary>
    /// Kaldes n�r et endeligt genkendelsesresultat (eller en fejlmeddelelse) er tilg�ngeligt.
    /// </summary>
    /// <param name="result">Det endelige tekstresultat eller en fejlbesked.</param>
    void OnResult(string result);

    /// <summary>
    /// Kaldes n�r mikrofonens lydniveau �ndrer sig (0..1).
    /// </summary>
    /// <param name="level">Det nye lydniveau, normaliseret i intervallet 0 til 1.</param>
    void OnVoiceLevelChanged(float level);

    /// <summary>
    /// Kaldes n�r mikrofonens tilstand �ndrer sig (t�ndt/slukket).
    /// </summary>
    /// <param name="isOn">Sandt hvis mikrofonen er aktiv/t�ndt; ellers falsk.</param>
    void OnMicrophoneStateChanged(bool isOn);
}
