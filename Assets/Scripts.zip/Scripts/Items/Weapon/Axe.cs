using UnityEngine;

public class Axe : Weapon
{
    [Header("Base Damage")]
    [SerializeField, Min(0)] private int baseDamage = 15;
    ///<summary>
    ///Beregner den skade en �kse g�r.
    ///</summary>
    ///<returns>Den samlede m�ngde skade.</returns>
    public override int CalculateDamage()
    {
        int totalDamage = Mathf.Max(0, baseDamage);

        return totalDamage;
    }

}
