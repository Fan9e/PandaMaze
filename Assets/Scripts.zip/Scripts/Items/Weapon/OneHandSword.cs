using UnityEngine;

public class OneHandSword : Weapon
{
    [Header("Base Damage")]
    [SerializeField, Min(0)] private int baseDamage = 10;
    ///<summary>
    ///Beregner den skade et enh�ndssv�rd g�r.
    ///</summary>
    ///<returns>Den samlede m�ngde skade.</returns>
    public override int CalculateDamage()
    {
        int totalDamage = Mathf.Max(0, baseDamage);

        return totalDamage;
    }

}
