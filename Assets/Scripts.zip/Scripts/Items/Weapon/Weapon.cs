using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public abstract class Weapon : Item, IWeapon
{
    [SerializeField] private string _attackAnimOverride;
    /// <summary>
    /// Returnerer navnet p� angrebs-animationen.
    /// Bruger <see cref="_attackAnimOverride"/> hvis det er sat;
    /// ellers bruges klassens navn efterfulgt af "Attack"
    /// </summary>
    public string AttackAnimationName =>
       string.IsNullOrEmpty(_attackAnimOverride)
           ? GetType().Name + "Attack"
           : _attackAnimOverride;
    public abstract int CalculateDamage();

    /// <summary>
    /// Kaldes n�r spilleren har sagt ordet rigtigt
    /// og vi vil sl� et bestemt monster.
    /// </summary>
    /// <param name="monster">Det monster, der skal modtage skaden</param>
    public void Attack(Monster monster)
    {
        if (monster == null) return;
        DealDamage(monster);
    }

    /// <summary>
    /// Udf�rer et slag mod det angivne monster ved at beregne skaden
    /// og anvende den.
    /// </summary>
    /// <param name="monster">Det monster, der skal modtage skaden</param>
    private void DealDamage(Monster monster)
    {
        int damage = CalculateDamage();
        //monster.Fight(damage);
    }

#if UNITY_EDITOR
    /// <summary>
    /// K�rer kun i Unity Editor og s�rger for,
    /// at <see cref="_attackAnimOverride"/> f�r en fornuftig standardv�rdi.
    /// Hvis feltet er tomt i Inspector, s�ttes det automatisk til navnet
    /// p� den type/komponent, som scriptet sidder p�.
    /// </summary>
    protected virtual void OnValidate()
    {
        if (string.IsNullOrEmpty(_attackAnimOverride))
            _attackAnimOverride = GetType().Name;
    }
#endif
}
