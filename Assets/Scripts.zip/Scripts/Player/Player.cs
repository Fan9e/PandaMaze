using UnityEngine;

public class Player : MonoBehaviour
{
    [SerializeField] private int _maxHealth = 100;
    [SerializeField] private int _currentHealth;

    public int MaxHealth
    {
        get => _maxHealth;
        set => _maxHealth = value;
    }

    public int CurrentHealth
    {
        get => _currentHealth;
        set => _currentHealth = value;
    }

    /// <summary>
    /// S�tter CurrentHealth til MaxHealth, n�r objektet starter.
    /// </summary>
    private void Start()
    {
        CurrentHealth = MaxHealth;
    }

}
