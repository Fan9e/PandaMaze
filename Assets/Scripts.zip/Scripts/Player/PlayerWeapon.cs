using System.Collections;
using UnityEngine;

public class PlayerWeapon : MonoBehaviour
{
    [Header("Weapon Auto Setup")]
    [Tooltip("Navnet p� det child, som bruges som v�ben-socket.")]
    [SerializeField]
    private string weaponSocketChildName = "WeaponPivot";

    [Tooltip("Navnet p� den Layer, som alle monstre ligger p� (for eksempel 'Monster').")]
    [SerializeField]
    private string monsterLayerName = "Monster";

    [Tooltip("Hvis den er tom, finder PlayerWeapon selv det f�rste Weapon i sine children.")]
    [SerializeField]
    private Weapon equippedWeaponComponent;

    [Tooltip("Hvis den er tom, finder PlayerWeapon selv socket-transformen via weaponSocketChildName.")]
    [SerializeField]
    private Transform weaponSocketTransform;

    [Tooltip("Hvis den er tom, finder PlayerWeapon selv en Animator, der kan bruges til v�ben-animationer.")]
    [SerializeField]
    private Animator weaponAnimator;

    [Header("Weapon Prefabs")]
    [SerializeField]
    private Weapon startingWeaponPrefab;

    /// <summary>
    /// Det aktuelt udstyrede v�ben, tilg�et via IWeapon-interfacet.
    /// </summary>
    public IWeapon EquippedWeaponInterface { get; private set; }

    [Header("Attack Settings")]
    [SerializeField]
    private float attackRadius = 2f;

    [SerializeField]
    private float attackDistanceForwardFromPlayer = 1f;

    [SerializeField]
    private LayerMask monsterLayerMask;

    [Tooltip("Hvis sand, l�ser PlayerWeapon selv input i Update.")]
    [SerializeField]
    private bool handleInputInThisComponent = true;

    private bool isCurrentlyAttacking;


    #region Unity Lifecycle

    /// <summary>
    /// Initialiserer v�bensystemet, n�r objektet bliver oprettet.
    /// Finder LayerMask til monstre, v�ben-socket, v�ben-komponent
    /// og den tilh�rende Animator.
    /// </summary>
    private void Awake()
    {
        SetupMonsterLayerMask();
        SetupWeaponSocketTransform();
        SetupWeaponComponent();
        SetupWeaponAnimator();
    }

    /// <summary>
    /// Hvis handleInputInThisComponent er sand, h�ndteres angrebsinput her.
    /// Ellers kan en anden komponent (for eksempel Player) kalde HandleAttackPlayerInput manuelt.
    /// </summary>
    private void Update()
    {
        if (handleInputInThisComponent)
        {
            HandleAttackPlayerInput();
        }
    }

    #endregion


    #region Setup Methods

    /// <summary>
    /// Sikrer at monsterLayerMask er sat til den korrekte Layer for monstre.
    /// Hvis masken endnu ikke har nogen v�rdi (0), og monsterLayerName ikke er tom,
    /// oprettes en LayerMask ud fra navnet (for eksempel "Monster").
    /// </summary>
    private void SetupMonsterLayerMask()
    {
        if (monsterLayerMask.value == 0 && !string.IsNullOrEmpty(monsterLayerName))
        {
            monsterLayerMask = LayerMask.GetMask(monsterLayerName);
        }
    }

    /// <summary>
    /// Finder og s�tter den transform, som v�bnet skal bruge som socket p� spilleren.
    /// Hvis weaponSocketTransform allerede er sat i Inspector, g�r metoden ikke noget.
    /// Ellers fors�ger den f�rst at finde et child med navnet weaponSocketChildName
    /// p� Player-objektet. Hvis det findes, bruges det som socket.
    /// Hvis der ikke findes noget matchende child, falder den tilbage til at bruge
    /// spillerens egen Transform som socket.
    /// </summary>
    private void SetupWeaponSocketTransform()
    {
        if (weaponSocketTransform != null)
        {
            return;
        }

        if (!string.IsNullOrEmpty(weaponSocketChildName))
        {
            Transform foundSocketTransform = transform.Find(weaponSocketChildName);
            if (foundSocketTransform != null)
            {
                weaponSocketTransform = foundSocketTransform;
                return;
            }
        }

        weaponSocketTransform = transform;
    }

    /// <summary>
    /// Finder eller opretter det v�ben, som spilleren skal bruge.
    /// Hvis der allerede sidder et Weapon som child, bruges det.
    /// Ellers bliver startingWeaponPrefab instansieret p� weaponSocketTransform.
    /// Til sidst s�ttes EquippedWeaponInterface, s� Player kan kalde Attack p� v�bnet.
    /// </summary>
    private void SetupWeaponComponent()
    {
        if (equippedWeaponComponent == null)
        {
            equippedWeaponComponent = GetComponentInChildren<Weapon>();
        }

        if (equippedWeaponComponent == null && startingWeaponPrefab != null)
        {
            if (weaponSocketTransform == null)
            {
                Debug.LogError("weaponSocketTransform er ikke sat, kan ikke spawne v�bnet.", this);
                return;
            }

            equippedWeaponComponent = Instantiate(startingWeaponPrefab, weaponSocketTransform);
            equippedWeaponComponent.transform.localPosition = Vector3.zero;
            equippedWeaponComponent.transform.localRotation = Quaternion.identity;
        }

        if (equippedWeaponComponent == null)
        {
            Debug.LogError("Player kunne hverken finde eller oprette noget Weapon.", this);
            return;
        }

        if (weaponSocketTransform != null &&
            equippedWeaponComponent.transform.parent != weaponSocketTransform)
        {
            equippedWeaponComponent.transform.SetParent(weaponSocketTransform, true);
        }

        EquippedWeaponInterface = equippedWeaponComponent as IWeapon;
        if (EquippedWeaponInterface == null)
        {
            Debug.LogError("Weapon-komponenten p� Player implementerer ikke IWeapon.", equippedWeaponComponent);
        }
    }


    /// <summary>
    /// Finder og s�tter den Animator, der skal bruges til v�bnets animationer.
    /// Hvis weaponAnimator allerede er sat, g�r metoden ikke noget.
    /// Ellers fors�ger den i denne r�kkef�lge:
    /// 1) At finde en Animator p� weaponSocketTransform eller dets children.
    /// 2) At finde en Animator p� equippedWeaponComponent eller dens parents.
    /// 3) At finde en vilk�rlig Animator i spillerens children.
    /// Hvis ingen Animator findes, logges en advarsel.
    /// </summary>
    private void SetupWeaponAnimator()
    {
        if (weaponAnimator != null)
        {
            return;
        }

        if (weaponSocketTransform != null)
        {
            weaponAnimator = weaponSocketTransform.GetComponentInChildren<Animator>();
        }

        if (weaponAnimator == null && equippedWeaponComponent != null)
        {
            weaponAnimator = equippedWeaponComponent.GetComponentInParent<Animator>();
        }

        if (weaponAnimator == null)
        {
            weaponAnimator = GetComponentInChildren<Animator>();
        }

        if (weaponAnimator == null)
        {
            Debug.LogWarning("PlayerWeapon kunne ikke finde nogen Animator til v�bnet.", this);
        }
    }

    #endregion


    #region Combat And Attacking

    //TODO: �ndre at man kan angribe med ordene, i stedet for med musen
    /// <summary>
    /// H�ndterer spillerens input til angreb.
    /// Tjekker om venstre museknap er trykket, om der allerede er et angreb i gang,
    /// om der er et v�ben udstyret, og om der findes et monster inden for angrebsr�kkevidde.
    /// Hvis alle betingelser er opfyldt, startes et angreb mod det n�rmeste monster.
    /// </summary>
    public void HandleAttackPlayerInput()
    {
        if (!Input.GetMouseButtonDown(0))
        {
            return;
        }

        if (isCurrentlyAttacking)
        {
            return;
        }

        if (EquippedWeaponInterface == null)
        {
            return;
        }

        Monster monster = GetClosestMonsterInAttackRange();
        if (monster == null)
        {
            return;
        }

        StartCoroutine(AttackRoutineCoroutine(monster));
    }

    /// <summary>
    /// H�ndterer et fuldt angreb mod det angivne monster.
    /// S�tter spilleren i angrebstilstand, afspiller angrebsanimationen
    /// og p�f�rer derefter skade via det udstyrede v�ben,
    /// hvis m�let stadig er gyldigt.
    /// </summary>
    /// <param name="monster">Det Monster, som spilleren fors�ger at angribe.</param>
    private IEnumerator AttackRoutineCoroutine(Monster monster)
    {
        isCurrentlyAttacking = true;

        yield return PlayAttackAnimationCoroutine();

        if (monster != null && EquippedWeaponInterface != null)
        {
            EquippedWeaponInterface.Attack(monster);
        }

        isCurrentlyAttacking = false;
    }

    /// <summary>
    /// Afspiller v�bnets angrebsanimation p� <see cref="weaponAnimator"/> 
    /// baseret p� navnet fra <see cref="IWeapon.AttackAnimationName"/>.
    /// Metoden venter cirka til animationen er f�rdig, f�r coroutine-forl�bet forts�tter.
    /// Hvis der ikke findes en gyldig animator eller et udstyret v�ben,
    /// bliver animationen ikke afspillet, og coroutine�en afsluttes med det samme.
    /// </summary>
    /// <returns>
    /// En <see cref="IEnumerator"/>, som bruges af Unitys coroutine-system
    /// til at afvikle animationens varighed over flere frames.
    /// </returns>
    private IEnumerator PlayAttackAnimationCoroutine()
    {
        if (weaponAnimator == null || EquippedWeaponInterface == null)
            yield break;

        string attackAnimationName = EquippedWeaponInterface.AttackAnimationName;
        Debug.Log($"Pr�ver at spille animation-state: {attackAnimationName}");

        weaponAnimator.Play(attackAnimationName, 0, 0f);

        yield return null;

        AnimatorStateInfo animatorStateInfo = weaponAnimator.GetCurrentAnimatorStateInfo(0);
        float animationLengthInSeconds = animatorStateInfo.length;

        if (animationLengthInSeconds <= 0.05f)
        {
            animationLengthInSeconds = 0.3f;
        }

        yield return new WaitForSeconds(animationLengthInSeconds);
    }

    /// <summary>
    /// Finder det n�rmeste monster, som befinder sig inden for spillerens angrebsomr�de.
    /// Angrebsomr�det er en usynlig kugle foran spilleren med centrum i
    /// spillerens position plus fremad-retningen gange attackDistanceForwardFromPlayer.
    /// Kun colliders p� monsterLayerMask bliver taget med.
    /// </summary>
    /// <returns>
    /// Det n�rmeste Monster inden for r�kkevidde,
    /// eller null hvis der ikke er nogen monstre i angrebsomr�det.
    /// </returns>
    private Monster GetClosestMonsterInAttackRange()
    {
        Vector3 attackCenter = transform.position + transform.forward * attackDistanceForwardFromPlayer;

        Collider[] hitColliders = Physics.OverlapSphere(attackCenter, attackRadius, monsterLayerMask);

        Monster closestMonster = null;
        float closestDistanceSquared = Mathf.Infinity;

        foreach (Collider hitCollider in hitColliders)
        {
            Monster monster = hitCollider.GetComponentInParent<Monster>();
            if (monster == null)
            {
                continue;
            }

            float distanceSquared =
                (monster.transform.position - attackCenter).sqrMagnitude;

            if (distanceSquared < closestDistanceSquared)
            {
                closestDistanceSquared = distanceSquared;
                closestMonster = monster;
            }
        }

        return closestMonster;
    }

    #endregion


    #region Weapon switching and equipping

    /// <summary>
    /// Udstyrer spilleren med et nyt v�ben.
    /// Det gamle v�ben bliver fjernet (destrueret), og det nye v�ben
    /// bliver placeret p� v�ben-socket'en og gjort til det aktive v�ben.
    /// </summary>
    /// <param name="newWeaponComponent">
    /// Den nye Weapon-komponent, som spilleren skal bruge.
    /// </param>
    public void EquipNewWeapon(Weapon weaponPrefab)
    {
        if (weaponPrefab == null)
        {
            Debug.LogWarning("EquipNewWeapon blev kaldt med null.", this);
            return;
        }

        if (equippedWeaponComponent != null)
        {
            Destroy(equippedWeaponComponent.gameObject);
        }

        if (weaponSocketTransform == null)
        {
            Debug.LogError("weaponSocketTransform er ikke sat, kan ikke equipppe nyt v�ben.", this);
            return;
        }

        equippedWeaponComponent = Instantiate(weaponPrefab, weaponSocketTransform);
        equippedWeaponComponent.transform.localPosition = Vector3.zero;
        equippedWeaponComponent.transform.localRotation = Quaternion.identity;

        EquippedWeaponInterface = equippedWeaponComponent as IWeapon;
        if (EquippedWeaponInterface == null)
        {
            Debug.LogError("Det nye Weapon implementerer ikke IWeapon.", equippedWeaponComponent);
        }

        SetupWeaponAnimator();
    }


    #endregion
}
